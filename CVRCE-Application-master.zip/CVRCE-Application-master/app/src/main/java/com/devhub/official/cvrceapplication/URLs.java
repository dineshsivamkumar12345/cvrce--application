package com.devhub.official.cvrceapplication;

public class URLs {

    // public static final String ROOT_URL ="http://192.168.137.136/www/public/api.php?apicall=";
    public static final String ROOT_URL ="http://devhub.co.in.cp-in-10.webhostbox.net/www/public/api.php?apicall=";
    public static final String URL_REGISTER=ROOT_URL+"signup";
    public  static final String URL_LOGIN=ROOT_URL+"login";
    public  static final String URL_COMPLAINT=ROOT_URL+"addComplaint";
    public static final String URL_MENTOR_LOGIN = ROOT_URL+"mentorLogin";
    public static final String URL_EMPLOYEE_LOGIN = ROOT_URL+"employeeLogin";
    public static final String SERVER_ADDR = "http://devhub.co.in.cp-in-10.webhostbox.net/www";
    // public static final String SERVER_ADDR = "http://192.168.137.136/www";
    // public static final String SERVER_ADDR = "http://engigyan.com/cvrce/www";
    // public static final String SERVER_ADDR = "http://172.29.8.90:8080/cvrce";
    // public static final String SERVER_ADDR = "http://192.168.43.226:8080/cvrce";

}
