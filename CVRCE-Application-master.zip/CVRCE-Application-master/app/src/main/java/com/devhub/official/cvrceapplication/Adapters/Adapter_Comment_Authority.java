package com.devhub.official.cvrceapplication.Adapters;

public class Adapter_Comment_Authority {
}
